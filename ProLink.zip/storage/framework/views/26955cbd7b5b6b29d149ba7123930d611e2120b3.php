<?php $__env->startSection('content'); ?>

<br>
<br>
<center>
    <h1 id="test" >
        Fenua ProLink
    </h1>
</center>
<br>
<br>
<div class="container-fluid">
    <div class="row">

        <div class="col-xl">
            <center>
                <div class="col" id="map">
                        <!-- Ici s'affichera la carte -->
                        affichage carte
                </div>
            </center>
        </div>
        <div class="col-xl ml-5 mr-5">
            <div class="col">
                    <h5>
                        Séléctionnez une catégorie
                    </h5>
                    <div class="form-group">
                        <?php if($category): ?>
                        <select class="form-control category" id="sel1">
                            <option value="">Choisir une catégorie</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item_category->id); ?>">
                                <?php echo e($item_category->name_category); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                    </div>
                <br>
                <h5>
                    Séléctionnez une spécialitée métier
                </h5>
                <div class="form-group">
                    <select class="form-control subcategory" id="sel1">

                    </select>
                </div>
                <br>
                <center>
                    <input class="btn btn-info rechercher" type="button" value="Rechercher">
                </center>
            </div>
            <br>
            <div class="col">
                <h5>
                    Liste profesionnel
                </h5>
                <center>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">Commune</th>
                            <th scope="col">Numéro</th>
                            <th scope="col">Last</th>
                            <th scope="col">RDV</th>
                          </tr>
                        </thead>
                        <tbody class="listpro">

                        </tbody>
                    </table>
                </center>
            </div>
        </div>
    </div>
</div>
<br>
<br>
<div class="col" id="publiciter">
    <center>
        <P>
            PUBLICITER
        </P>
    </center>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joane\Desktop\VaiariiTemplate\ProLink\resources\views/home.blade.php ENDPATH**/ ?>