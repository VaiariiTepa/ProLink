<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rdv_types extends Model
{
    public $fillable=[
        'name'
    ];
}
